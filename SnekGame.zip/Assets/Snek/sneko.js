
// Board
var blocksize = 25;
var rows = 20;
var columns = 20;
var board;
var context;


var snakeX = blocksize * 5; // This means it'll start at 5 tiles across...
var snakeY = blocksize * 5; // And 5 down!
var velocityX = 0;
var velocityY = 0;
var snakeBody = [];
var gameOver = false;
var musictime = 333;
// These are the rule descriptions for EVERY rule.
var ruletext = ["Basic Snake, but every apple you eat adds a new rule. Have fun!", "Sound and Music!", "5 Random Walls.", "Blue portal tile! Teleports your head 3 tiles forwards!",
"Portal gets re-randomized after every apple.", "3 more walls.",
"2 Orange shifter tiles! When you go on it, all walls go one space down. If they go off the board, they get re-randomized.",
"2 Yellow snecko mode tiles! While snecko, you can't use orange or blue tiles.",
"2 White restore tiles! Puts you back as a normal snek, reseting your mode.",
"3 Pink phantom mode tiles! Puts your snek into phantom mode, meaning you can't eat food, but can go through walls.",
"1 Smart wall tile! Looks and acts like a wall, except it moves one tile in the direction you're facing whenever you change direction.",
"Purple slowsnek tile! Puts you in slowsnek mode, meaning you move half speed but can't change to any mode other than snek."];

var wallPosX = [];
var wallPosY = [];

var portalX = 0;
var portalY = 0;

var shifterX = [];
var shifterY = [];

var snakeMode = "lime";
var sneckoModeX = [];
var sneckoModeY = [];

var restoreModeX = [];
var restoreModeY = [];

var phantomModeX = [];
var phantomModeY = [];

var snakeAction = 0;

var smartWallX = 0;
var smartWallY = 0;

var slowsnek = {
    X: -1,
    Y: 0
}

window.onload = function() {
    board = document.getElementById("board");
    board.height = rows * blocksize;
    board.width = columns * blocksize;
    context = board.getContext("2d");
    placeFood();
    document.getElementById("rule-text").innerText = ruletext[snakeBody.length];
    document.addEventListener("keyup", changeDirection);
    setInterval(update, 1000/10);
}
// Where all the magic happens: update();
update = function() {
    bgmusic();
    if (gameOver) {
        return;
    }
    // Game Background
    context.fillStyle="black";
    context.fillRect(0, 0, board.width, board.height);
    // Shifter
    if (snakeBody.length >= 6) {
        for (i = 0; i < shifterX.length; i++) {
            context.fillStyle="orange";
            context.fillRect(shifterX[i], shifterY[i], blocksize, blocksize)
            if (shifterX[i] == snakeX && shifterY[i] == snakeY && snakeMode != "yellow") {
                let shiftSound = new Audio('Assets/Snek/Turn.mp3')
                shiftSound.play();
                smartWallY += blocksize;
                for (i = 0; i < wallPosX.length; i++) {
                    wallPosY[i] += blocksize;
                    var iStore = i;
                    if (wallPosY[iStore] >= rows * blocksize) {
                        wallPosX[iStore] = (Math.floor(Math.random() * columns) * blocksize);
                        wallPosY[iStore] = (Math.floor(Math.random() * columns) * blocksize);
                    }
                }
            }
        }
        
    }
    // Yellow snecko mode tiles
    for (i = 0; i < sneckoModeX.length; i++) {
        context.fillStyle="yellow";
        context.fillRect(sneckoModeX[i], sneckoModeY[i], blocksize, blocksize);
        if (snakeX == sneckoModeX[i] && snakeY == sneckoModeY[i] && snakeMode != "yellow") {
            snakeMode = "yellow";
            let changeSound = new Audio('Assets/Snek/Change.wav')
            changeSound.play();
        }
    }
    // White sneck mode tiles
    for (i = 0; i < restoreModeX.length; i++) {
        context.fillStyle="white";
        context.fillRect(restoreModeX[i], restoreModeY[i], blocksize, blocksize);
        if (snakeX == restoreModeX[i] && snakeY == restoreModeY[i] && snakeMode != "lime") {
            snakeMode = "lime";
            let changeSound = new Audio('Assets/Snek/Change.wav')
            changeSound.play();
        }
    }
    // White sneck mode tiles
    for (i = 0; i < phantomModeX.length; i++) {
        context.fillStyle="pink";
        context.fillRect(phantomModeX[i], phantomModeY[i], blocksize, blocksize);
        if (snakeX == phantomModeX[i] && snakeY == phantomModeY[i] && snakeMode != "pink") {
            snakeMode = "pink";
            let changeSound = new Audio('Assets/Snek/Change.wav')
            changeSound.play();
        }
    }
    // Purple slowsnek mode tiles
    if (slowsnek.X != -1) {
        context.fillStyle="purple"
        context.fillRect(slowsnek.X, slowsnek.Y, blocksize, blocksize);
    }
    
    // Portal
    if (snakeBody.length > 2) {
        context.fillStyle="blue";
        context.fillRect(portalX, portalY, blocksize, blocksize);
        
    }
    
    // Walls
    for (i = 0; i < wallPosX.length; i++) {
        context.fillStyle="grey";
        context.fillRect(wallPosX[i], wallPosY[i], blocksize, blocksize);
    }
    // Smart wall
    if (snakeBody.length >= 10) {
        context.fillStyle="grey";
        context.fillRect(smartWallX, smartWallY, blocksize, blocksize);
        if (smartWallX < 0 || smartWallX >= columns * blocksize || smartWallY < 0 || smartWallY >= rows * blocksize) {
            smartWallX = Math.floor(Math.random() * columns) * blocksize;
            smartWallY = Math.floor(Math.random() * rows) * blocksize;
        }
    }
    // Apples
    context.fillStyle="red";
    context.fillRect(foodX, foodY, blocksize, blocksize);
    for (i = 0; i < wallPosX.length; i++) {
        while (foodX == wallPosX[i] && foodY == wallPosY[i]) {
            placeFood();
            context.fillStyle="red";
            context.fillRect(foodX, foodY, blocksize, blocksize);
        }
    }
    
    snakeMove();
    
    if (snakeX == foodX && snakeY == foodY && snakeMode != "pink") {
        if (snakeBody.length != 3) {
            portalX = Math.floor(Math.random() * columns) * blocksize;
            portalY = Math.floor(Math.random() * rows) * blocksize;
        }
        let eatsfx = new Audio('Assets/Snek/Eat.mp3')
        eatsfx.play();
        snakeBody.push([foodX, foodY])
        document.getElementById("score").innerText = snakeBody.length.toString();
        
        rulesUpdate();
        placeFood();
        
    }
}
// Controls the background music
const music = new Audio('Assets/Snek/50. Houston.mp3')
bgmusic = function() {
    if (musictime > 332 && snakeBody.length > 0) {
        music.play();
        musictime = 0;
    }
}
// SNAKE!
snakeMove = function() {
    // Movement Stuff
    
    for (let i = snakeBody.length-1; i > 0; i--) {
        snakeBody[i] = snakeBody[i-1];
    }
    if (snakeBody.length) {
        snakeBody[0] = [snakeX, snakeY];
    }
    snakeX += velocityX * blocksize;
    snakeY += velocityY * blocksize;
    for (i = 0; i < wallPosX.length; i++) {
        if (snakeX == wallPosX[i] && snakeY == wallPosY[i] && snakeMode != "pink") {
            YouDied();
        }
    }
    // Drawing method for the snake
    context.fillStyle=snakeMode;
    context.fillRect(snakeX, snakeY, blocksize, blocksize);
    for (let i = 0; i < snakeBody.length; i++) {
        context.fillRect(snakeBody[i][0], snakeBody[i][1], blocksize, blocksize);
    }
    // Collision Detection
    if (snakeX < 0 || snakeX >= columns * blocksize || snakeY < 0 || snakeY >= rows * blocksize) {
        YouDied();
    }
    for (let i = 0; i < snakeBody.length; i++) {
        if (snakeX == snakeBody[i][0] && snakeY == snakeBody[i][1]) {
            YouDied();
        }
    }
    if (snakeX == portalX && snakeY == portalY && snakeMode != "yellow") {
        let warpSound = new Audio('Assets/Snek/Warp.mp3')
        warpSound.play();
        snakeX += velocityX * 3 * blocksize;
        snakeY += velocityY * 3 * blocksize;
    }
    if (snakeX == slowsnek.X && snakeY == slowsnek.Y && snakeMode != "purple") {
        snakeMode = "purple";
        let changeSound = new Audio('Assets/Snek/Change.wav')
        changeSound.play();
    }
    if (snakeX == smartWallX && snakeY == smartWallY && snakeMode != "pink") {
        YouDied();
    }
}
YouDied = function () {
    gameOver = true;
    music.pause();
    music.currentTime = 0;
    let bewoop = new Audio('Assets/Snek/GameOver.mp3')
    bewoop.play();
    document.getElementById("GameOver").innerText = "GAME OVER";
}

changeDirection = function(e) {
    if (e.code == "ArrowUp" && velocityY != 1) {
        velocityX = 0;
        velocityY = -1;
        smartWallY += velocityY * blocksize;
    } else if (e.code == "ArrowDown" && velocityY != -1) {
        velocityX = 0;
        velocityY = 1;
        smartWallY += velocityY * blocksize;
    } else if (e.code == "ArrowLeft" && velocityX != 1) {
        velocityX = -1;
        velocityY = 0;
        smartWallX += velocityX * blocksize;
    } else if (e.code == "ArrowRight" && velocityX != -1) {
        velocityX = 1;
        velocityY = 0;
        smartWallX += velocityX * blocksize;
    }
    
}
// Food *Yum*
var foodX;
var foodY;

placeFood = function() {
    foodX = Math.floor(Math.random() * columns) * blocksize;
    foodY = Math.floor(Math.random() * rows) * blocksize;
}

// The Rules
rulesUpdate = function() {
    document.getElementById("rule-text").innerText = ruletext[snakeBody.length];
        if (snakeBody.length == 1) {
            // Nothing yet...
        } else if (snakeBody.length == 2) {
            for (i = 0; i < 5; i++) {
                wallPosX.push(Math.floor(Math.random() * columns) * blocksize);
                while (wallPosX[i] == snakeX) {
                  wallPosX[i] = Math.floor(Math.random() * columns) * blocksize
                }
                wallPosY.push(Math.floor(Math.random() * columns) * blocksize);
                while (wallPosY[i] == snakeY) {
                    wallPosY[i] = Math.floor(Math.random() * columns) * blocksize
                }
            }
        } else if (snakeBody.length == 3) {
            portalX = Math.floor(Math.random() * columns) * blocksize;
            portalY = Math.floor(Math.random() * rows) * blocksize;
        } else if (snakeBody.length == 5) {
            for (i = 0; i < 3; i++) {
                wallPosX.push(Math.floor(Math.random() * columns) * blocksize);
                wallPosY.push(Math.floor(Math.random() * columns) * blocksize);
            }
        } else if (snakeBody.length == 6) {
            for (i = 0; i < 2; i++) {
                shifterX.push(Math.floor(Math.random() * columns) * blocksize);
                shifterY.push(Math.floor(Math.random() * columns) * blocksize);
            }
        } else if (snakeBody.length == 7) {
            for (i = 0; i < 2; i++) {
                sneckoModeX.push(Math.floor(Math.random() * columns) * blocksize);
                sneckoModeY.push(Math.floor(Math.random() * columns) * blocksize);
            }
        } else if (snakeBody.length == 8) {
            for (i = 0; i < 2; i++) {
                restoreModeX.push(Math.floor(Math.random() * columns) * blocksize);
                restoreModeY.push(Math.floor(Math.random() * columns) * blocksize);
            }
        } else if (snakeBody.length == 9) {
            for (i = 0; i < 3; i++) {
                phantomModeX.push(Math.floor(Math.random() * columns) * blocksize);
                phantomModeY.push(Math.floor(Math.random() * columns) * blocksize);
            }
        } else if (snakeBody.length == 10) {
            smartWallX = Math.floor(Math.random() * columns) * blocksize;
            smartWallY = Math.floor(Math.random() * rows) * blocksize;
        } else if (snakeBody.length == 11) {
            slowsnek.X = Math.floor(Math.random() * columns) * blocksize;
            slowsnek.Y = Math.floor(Math.random() * rows) * blocksize;
        }
    }
